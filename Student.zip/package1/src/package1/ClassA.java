package package1;
public class ClassA 
{
	    private int studentRollNumber;
	    private String studentName;
	    private String mailid;
	    private String address;

	    public int getStudentRollNumber() {
	        return studentRollNumber;
	    }

	    public void setStudentRollNumber(int studentRollNumber) {
	        this.studentRollNumber = studentRollNumber;
	    }

	    public String getStudentName() {
	        return studentName;
	    }

	    public void setStudentName(String studentName) {
	        this.studentName = studentName;
	    }
	}
	